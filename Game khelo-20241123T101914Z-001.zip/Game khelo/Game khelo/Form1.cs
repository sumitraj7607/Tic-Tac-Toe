﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Game_khelo
{
    public partial class Form1 : Form
    {
        char Who = 'O';
        short movement = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Disablebuttons();
        }
        private void Disablebuttons()
        {
            EnableDisablebuttons(false);

        }

        private void startGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
           EnableDisablebuttons( true); 
           EnableDisablepanels(false);
        }
        private void EnableDisablebuttons(bool value)
        {
            button1.Enabled=value;
            button2.Enabled=value;
            button3.Enabled=value;
            button4.Enabled=value;
            button5.Enabled=value;
            button6.Enabled=value;
            button7.Enabled=value;
            button8.Enabled=value;
            button9.Enabled=value;
        }
        private void EnableDisablepanels(bool value)
        {
            Playerinformationpanles.Enabled=value;
            Gamesettingpanels.Enabled=value;
        }

        private void resetGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EnableDisablebuttons(false);
            EnableDisablepanels(true);
           // Counter = 0;
            ResetGame();
        }

         private void ResetGame()
        {

            EnableDisablebuttons(false);
            EnableDisablepanels(true);
          //  Counter = 0;
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void aboutUsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Khelo Game","Aboutus",MessageBoxButtons.OK,MessageBoxIcon.Information);
        }

        private void button_click(object sender, EventArgs e)
        {
            Button bt = sender as Button;
            bt.Enabled=false;
            bt.BackColor = Color.OrangeRed;
            if(Who =='O')
            {
                bt.Text = "O";
                Who = 'X';

            }
            else if(Who =='X')
                 {
                     bt.Text="X";
                     Who = 'O';
                     

                 }

           
            }
        private void checkWinner()
        {
           // if(Counter==9)
            {
                MessageBox.Show("Game is Draw,please try again.", "Game Draw", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ResetGame();
            }
        }
    }
}
